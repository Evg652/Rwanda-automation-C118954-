<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>title_tax</name>
   <tag></tag>
   <elementGuidId>1fae4aca-2fee-43cb-93d0-a87b1bc1a9c3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[(text() = ' Tax ' or . = ' Tax ')]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='FRw8120'])[4]/following::td[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>td</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>elem</name>
      <type>Main</type>
      <value>title</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>totals__title</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> Tax </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-root[1]/hot-layout[1]/div[@class=&quot;layout&quot;]/div[@class=&quot;layout__header-wrapper&quot;]/hot-header[@class=&quot;layout__header&quot;]/header[@class=&quot;header&quot;]/div[@class=&quot;header__top&quot;]/hot-nav[@class=&quot;header__nav&quot;]/div[@class=&quot;nav&quot;]/div[@class=&quot;nav__list-b&quot;]/div[@class=&quot;nav__list&quot;]/div[@class=&quot;nav__item nav__item--cart&quot;]/hot-cart-icon[@class=&quot;nav__link nav__link--no-hover&quot;]/hot-modal[1]/div[@class=&quot;modal modal--opening&quot;]/div[@class=&quot;modal__dialog&quot;]/div[@class=&quot;modal__body&quot;]/div[@class=&quot;modal__content&quot;]/hot-cart-modal[1]/div[@class=&quot;cart-m cart-m--not-empty&quot;]/div[@class=&quot;cart-m__is-not-empty&quot;]/hot-cart-totals[@class=&quot;cart-m__totals&quot;]/table[@class=&quot;totals totals--cart&quot;]/tbody[1]/tr[@class=&quot;totals__row&quot;]/td[@class=&quot;totals__title&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='FRw8120'])[4]/following::td[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Empties deposit'])[4]/following::td[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='FRw40'])[2]/preceding::td[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Total discount'])[2]/preceding::td[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[9]/hot-cart-icon/hot-modal/div/div/div/div[2]/hot-cart-modal/div/div[2]/hot-cart-totals/table/tbody/tr[4]/td</value>
   </webElementXpaths>
</WebElementEntity>
