import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable

WebUI.callTestCase(findTestCase('addItemsToCart_desktop'), [:], FailureHandling.STOP_ON_FAILURE)

WebUI.verifyElementPresent(findTestObject('Temp/title_yourCart'), 20)

WebUI.verifyElementPresent(findTestObject('Temp/title_youHaveXItemsInYourCart'), 20)

WebUI.verifyElementPresent(findTestObject('Temp/title_estimatedDeliveryDate'), 20)

WebUI.verifyElementPresent(findTestObject('Temp/title_estimatedDeliveryDateValue'), 20)

WebUI.verifyElementPresent(findTestObject('Temp/block_listOfProducts'), 20)

WebUI.verifyElementPresent(findTestObject('Temp/title_subTotal'), 20)

WebUI.verifyElementPresent(findTestObject('Temp/title_SubtotalValue'), 20)

WebUI.verifyElementPresent(findTestObject('Temp/title_emptiesDeposit'), 20)

WebUI.verifyElementPresent(findTestObject('Temp/title_emptiesDepositValue'), 20)

WebUI.verifyElementPresent(findTestObject('Temp/title_tax'), 20)

WebUI.verifyElementPresent(findTestObject('Temp/title_taxValue'), 20)

WebUI.verifyElementPresent(findTestObject('Temp/title_total'), 20)

WebUI.verifyElementPresent(findTestObject('Temp/title_totalValue'), 20)

WebUI.verifyElementPresent(findTestObject('Temp/button_checkout'), 20)

WebUI.closeBrowser()

